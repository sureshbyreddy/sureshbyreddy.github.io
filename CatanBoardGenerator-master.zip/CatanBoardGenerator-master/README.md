# CatanBoardGenerator
Generate a Settlers of Catan game.

<b>Current Features:</b>
- Generate a 3-4 player Catan Board + print.
- Generate all resources cards + export to pdf.
- Generate the Longest Road, Largest Army, and Building Cost cards.

<b>ToDo:</b>
- Different board types (expansion,seafarers,cities and knights).
- Landscape Print for the board.
- Editable size for board.
- Developement Cards.
- Oragami pieces.
- Make it responsive
- Clean up the CSS







...don't sue me Klaus Teuber
